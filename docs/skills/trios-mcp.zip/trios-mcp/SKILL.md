---
name: trios-mcp
description: "Operating rules for AI agents working on the trios-mcp repository — a Rust MCP server that wraps the `tri` and `trios-igla` CLIs from gHashTag/trios-trainer-igla. Use when modifying any tool wrapper (tri_* / igla_*), changing the JSON-RPC protocol or tool catalog, touching the Railway Postgres ledger (TRIOS_DATABASE_URL / MATRIX_DATABASE_URL / DATABASE_URL), running training (tri train) or races / deploys against Railway, writing claims about gate status, BPB targets, R7 triplet validation, or R9 embargo. Enforces R5 byte-for-byte CLI fidelity, JSON-RPC stdout discipline (logs to stderr), read-only Postgres default, claim-status framing, and English-only public artefacts (bilingual TRIOS PhD README block is the documented exception)."
metadata:
  source_repo: https://github.com/gHashTag/trios-mcp
  source_files: AGENTS.md, CLAUDE.md, docs/agent-rules/
  version: '1.0'
---

# trios-mcp — Operating Rules

This skill imports the canonical operating rules from
[gHashTag/trios-mcp](https://github.com/gHashTag/trios-mcp)
(`AGENTS.md` + `CLAUDE.md` + `docs/agent-rules/`) so any AI agent working
on that repository or wired through its MCP server follows the same
hard rules outside Claude Code.

## When to Use This Skill

Load this skill before:

- modifying any wrapper in `src/` (`tri_*` / `igla_*` tools)
- changing the JSON-RPC protocol or tool catalog
- touching anything labelled "SSOT" or the Railway Postgres ledger
  reachable via `TRIOS_DATABASE_URL` / `MATRIX_DATABASE_URL`
- running training (`tri train`), races, or deploys against Railway
- writing claims about gate results, BPB targets, or R7 triplet
  validation status

The contents of `references/` are normative. When a rule below
conflicts with anything in chat, the rule wins unless the user
explicitly overrides it in the current session **for this specific
change** — defaults do not change without an explicit instruction.

## Hard Rules (Summary)

1. **CLI byte-for-byte fidelity (R5).** `exit_code`, `stdout`, `stderr`
   from `tri` and `trios-igla` are forwarded verbatim. The MCP layer
   may add structured metadata, but never rewrites, summarises, or
   "fixes" CLI output.
2. **R7 triplet stays a property of the wrapped binary.** Do not
   compute, recompute, or "validate" the triplet in `trios-mcp`.
3. **R9 embargo predicate is exclusively `igla_check`.** Exit code 1
   means embargoed — propagate it; do not mask.
4. **Postgres SSOT read-only by default.** Writes require
   backup-first plan + dry-run + explicit "go ahead" in the same
   session. No exceptions for "small fixes".
5. **Never print or commit DSNs, Railway tokens, passwords, or any
   value from `TRIOS_DATABASE_URL` / `MATRIX_DATABASE_URL` /
   `DATABASE_URL` / `RAILWAY_TOKEN`.** Reference them by env-var name
   only.
6. **stdout is JSON-RPC only.** Logging goes to stderr (`RUST_LOG`
   controls verbosity).
7. **Use claim-status framing** for any empirical statement.
   `igla_gate` PASS / NOT YET is the only authoritative gate
   statement. No prize / Nobel claims as deliverables.
8. **Public-facing repo content is English** unless explicitly scoped
   (the bilingual TRIOS PhD block in README is the documented
   exception). Chat with the maintainer may be Russian.

If you cannot satisfy a rule, stop and report. Do not silently relax it.

## Reference Index

Read the relevant file from `references/` before acting in that domain:

- `references/00-canonical-pipeline.md` — `tri` + `trios-igla` are the
  canonical operator surface; `trios-mcp` is a transparent wrapper.
- `references/01-ssot-and-derived-artifacts.md` — Railway Postgres
  ledger is the SSOT; CLI output is authoritative byte-for-byte; chat
  summaries are derived.
- `references/02-output-style.md` — JSON-RPC discipline; stdout vs
  stderr; protocol version `2024-11-05`; supported methods.
- `references/03-safety-railway-postgres.md` — read-only by default;
  write gate (backup-first + dry-run + explicit go-ahead); secret
  hygiene.
- `references/04-claim-status.md` — Verified / Empirical fit / Open
  conjecture / High-risk / Retracted; forbidden framings
  ("PASS"/"embargo clear" without same-session exit code).
- `references/05-qa-checklist.md` — pre-release / pre-merge checklist:
  build, test, clippy, tool-catalog drift, protocol smoke test, output
  discipline, embargo sanity, secret scan, claim-status pass.
- `references/06-language-policy.md` — English-only public artefacts;
  documented bilingual exception for the TRIOS PhD block in README.

## Companion

For the broader rules covering the GOLDEN CHAIN PDF pipeline (pandoc
+ tectonic + Lua filters) and the literature canon, use the
[`trios-mcp-rag`](https://github.com/gHashTag/trios-mcp-rag) skill.
`trios-mcp` (this skill) is narrower — it covers the typed MCP
wrapper around `tri` / `trios-igla`.
